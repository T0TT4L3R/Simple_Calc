const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync(path.resolve(__dirname, 'button.html'), 'utf-8');
let document, window, display;

beforeEach(() => {
  const dom = new JSDOM(html, { runScripts: 'dangerously' });
  window = dom.window;
  document = window.document;
  display = document.getElementById('display');
});

test('Dodaje liczby do wyświetlacza', () => {
  window.appendValue('2');
  window.appendValue('+');
  window.appendValue('3');
  expect(display.value).toBe('2+3');
});

test('Czyści wyświetlacz', () => {
  window.appendValue('2');
  window.clearDisplay();
  expect(display.value).toBe('');
});

test('Oblicza wyrażenie poprawnie', () => {
  window.appendValue('2');
  window.appendValue('+');
  window.appendValue('3');
  window.calculate();
  expect(display.value).toBe('5');
});

test('Wyświetla błąd dla niepoprawnego wyrażenia', () => {
  window.appendValue('2');
  window.appendValue('/');
  window.appendValue('0');
  window.calculate();
  expect(display.value).toBe('Błąd');
});
